# IBM-Project-40798-1664170001
Natural Disasters Intensity Analysis and Classification using Artificial Intelligence
